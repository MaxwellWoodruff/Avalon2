using UnityEngine;


public class PlayerCollision : MonoBehaviour
{
public float coli;


    void OnCollisionEnter2D(Collision2D col)
    {
    }
    
    
}
